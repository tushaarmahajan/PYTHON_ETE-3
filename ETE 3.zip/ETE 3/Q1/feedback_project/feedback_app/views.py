from django.shortcuts import render
from .forms import FeedbackForm

def feedback_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            return render(request, 'feedback_app/feedback.html', {'form': form, 'message': 'Thank you for your feedback!'})
    else:
        form = FeedbackForm()
    return render(request, 'feedback_app/feedback.html', {'form': form})